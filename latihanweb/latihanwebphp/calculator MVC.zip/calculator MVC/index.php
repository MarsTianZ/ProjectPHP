<?php
require_once 'controllers/CalculatorController.php';

$controller = new CalculatorController();
$controller->index();
?>